# -*- coding: utf-8 -*-
"""
PIPELINE DE ETL E MINERAÇÃO DE DADOS - TERRABRASILIS / DETER-INPE
Projeto: Priorização da Fiscalização do Desmatamento na Amazônia Legal
Equipe: Diego Feitosa & Diego Braga
Cliente: Secretaria Estadual de Meio Ambiente

Este script executa integralmente as etapas da Seção 3 (Limpeza e Mineração)
e Seção 4 (Regras de Negócio RN-P1 a RN-P5) do Relatório Executivo.
"""

import unicodedata
import numpy as np
import pandas as pd


def remover_acentos_padronizar(texto: str) -> str:
    """Etapa 3.1.4: Padronização UTF-8, remoção de acentos, Trim e Upper."""
    if pd.isna(texto):
        return ""
    texto_limpo = str(texto).strip().upper()
    return "".join(
        c for c in unicodedata.normalize("NFD", texto_limpo)
        if unicodedata.category(c) != "Mn"
    )


def executar_pipeline_etl(caminho_csv_bruto: str, caminho_d_municipio: str):
    print("1. Carregando dados brutos extraídos do TerraBrasilis (DETER/INPE)...")
    df = pd.read_csv(caminho_csv_bruto)
    df_mun = pd.read_csv(caminho_d_municipio)
    print(f"   Registros brutos lidos: {len(df)}")

    # -------------------------------------------------------------------------
    # SEÇÃO 3.1 - MÉTODO DE LIMPEZA E TRATAMENTO DE DADOS (5 ETAPAS)
    # -------------------------------------------------------------------------
    # 1. Filtro Temporal de Janela Móvel (24 Meses: Nov/2024 a Out/2026)
    df["VIEW_DATE"] = pd.to_datetime(df["VIEW_DATE"], errors="coerce")
    df = df[
        (df["VIEW_DATE"] >= "2024-11-01") &
        (df["VIEW_DATE"] <= "2026-10-31")
    ].copy()

    # 2. Filtro de Classes Alvo de Fiscalização
    classes_alvo = ["DESMATAMENTO_CR", "DESMATAMENTO_VEG", "MINERACAO"]
    df = df[df["CLASSNAME"].isin(classes_alvo)].copy()

    # 3. Remoção de Ruído Espacial (Sliver Polygons < 0,03 km² / 3 ha) e Duplicatas de GID
    df["AREA_KM2"] = pd.to_numeric(df["AREA_KM2"], errors="coerce").fillna(0.0)
    df = df[df["AREA_KM2"] >= 0.03].copy()
    df = df.drop_duplicates(subset=["GID"], keep="first").copy()

    # 4. Padronização de Chaves e Textos (Data Hygiene)
    df["MUNICIPIO"] = df["MUNICIPIO"].apply(remover_acentos_padronizar)
    df["CD_MUN"] = df["CD_MUN"].astype(int)

    # 5. Tipagem Forte e Mineração Espacial (Buffer de 10 km de UCs e TIs - Seção 3.2)
    df["DIST_UC_TI_KM"] = pd.to_numeric(df["DIST_UC_TI_KM"], errors="coerce").fillna(999.0)
    df["FLAG_BUFFER_10KM"] = np.where(df["DIST_UC_TI_KM"] <= 10.0, 1, 0)

    print(f"   Registros após limpeza (Seção 3.1): {len(df)}")

    # -------------------------------------------------------------------------
    # SEÇÃO 3.2 & SEÇÃO 4 - MINERAÇÃO DE DADOS E REGRAS DE NEGÓCIO (RN-P1 a RN-P5)
    # -------------------------------------------------------------------------
    df_12m_atuais = df[df["VIEW_DATE"] >= "2025-11-01"].copy()
    df_12m_ant = df[df["VIEW_DATE"] < "2025-11-01"].copy()

    df_12m_atuais["Ano_Mes"] = df_12m_atuais["VIEW_DATE"].dt.strftime("%Y-%m")
    meses_ordenados = sorted(df_12m_atuais["Ano_Mes"].unique())
    mapa_x = {ym: i + 1 for i, ym in enumerate(meses_ordenados)}
    df_12m_atuais["X_Mes"] = df_12m_atuais["Ano_Mes"].map(mapa_x)

    total_alertas_amazonia = len(df_12m_atuais)
    metricas_municipios = []

    for _, mun in df_mun.iterrows():
        cd = int(mun["CD_MUN"])
        sub_atu = df_12m_atuais[df_12m_atuais["CD_MUN"] == cd]
        sub_ant = df_12m_ant[df_12m_ant["CD_MUN"] == cd]

        # RN-P1: Concentração de Alertas
        tot_12m = len(sub_atu)
        area_12m = round(sub_atu["AREA_KM2"].sum(), 2)
        part_pct = round((tot_12m / total_alertas_amazonia) * 100, 2)

        # RN-P2: Tendência de Crescimento (Variação Anual % e Inclinação OLS Beta)
        tot_ant = len(sub_ant)
        var_anual_pct = round(((tot_12m - tot_ant) / tot_ant) * 100, 2) if tot_ant > 0 else 0.0

        # Regressão Linear OLS (y = alpha + beta * x) com preenchimento de zeros para meses sem alerta
        serie_mensal = sub_atu.groupby("X_Mes").size().reindex(range(1, 13), fill_value=0)
        x = np.arange(1, 13, dtype=float)
        y = serie_mensal.values.astype(float)
        beta_ols = round(np.sum((x - x.mean()) * (y - y.mean())) / np.sum((x - x.mean()) ** 2), 2)

        # RN-P3: Proximidade de Áreas Protegidas (Buffer <= 10 km de UC ou TI)
        alertas_10km = int(sub_atu["FLAG_BUFFER_10KM"].sum())
        pct_10km = round((alertas_10km / tot_12m) * 100, 2) if tot_12m > 0 else 0.0

        metricas_municipios.append({
            "CD_MUN": cd,
            "Municipio": mun["NM_MUN_EXIBICAO"],
            "UF": mun["SIGLA_UF"],
            "Total_Alertas_12m": tot_12m,
            "Area_Desmatada_km2": area_12m,
            "Participacao_Total_Pct": part_pct,
            "Alertas_12m_Anteriores": tot_ant,
            "Variacao_Anual_Pct": var_anual_pct,
            "Tendencia_Mensal_Beta_OLS": beta_ols,
            "Alertas_Buffer_10km": alertas_10km,
            "Pct_Alertas_Areas_Protegidas": pct_10km,
        })

    df_res = pd.DataFrame(metricas_municipios)

    # Normalização Estatística Min-Max [0, 1] (Seção 3.2)
    for col_orig, col_norm in [
        ("Total_Alertas_12m", "P1_Norm_Volume"),
        ("Tendencia_Mensal_Beta_OLS", "P2_Norm_Tendencia"),
        ("Pct_Alertas_Areas_Protegidas", "P3_Norm_Proximidade"),
    ]:
        c_min, c_max = df_res[col_orig].min(), df_res[col_orig].max()
        df_res[col_norm] = np.round((df_res[col_orig] - c_min) / (c_max - c_min), 4)

    # RN-P4: Índice de Priorização Multicritério (W1=0.40, W2=0.30, W3=0.30)
    W1, W2, W3 = 0.40, 0.30, 0.30
    df_res["Indice_Priorizacao_IP"] = np.round(
        W1 * df_res["P1_Norm_Volume"] +
        W2 * df_res["P2_Norm_Tendencia"] +
        W3 * df_res["P3_Norm_Proximidade"],
        3
    )

    # Faixas de Decisão Operacional (RN-P4)
    df_res["Faixa_Decisao_RN_P4"] = np.where(
        df_res["Indice_Priorizacao_IP"] >= 0.75,
        "Prioridade Crítica (Força-Tarefa Permanente)",
        np.where(
            df_res["Indice_Priorizacao_IP"] >= 0.50,
            "Prioridade Alta (Operações Táticas)",
            "Monitoramento (Remoto e Ações Locais)"
        )
    )

    df_res = df_res.sort_values(by="Indice_Priorizacao_IP", ascending=False).reset_index(drop=True)
    df_res.insert(0, "Rank_Prioridade", df_res.index + 1)

    return df, df_res


if __name__ == "__main__":
    df_limpo, df_priorizacao = executar_pipeline_etl(
        "fAlertas_DETER_Bruto_TerraBrasilis.csv",
        "dMunicipio.csv"
    )
    print("\nResultado da Mineração Multicritério (RN-P1 a RN-P4):")
    print(df_priorizacao[["Rank_Prioridade", "Municipio", "UF", "Total_Alertas_12m", "Indice_Priorizacao_IP", "Faixa_Decisao_RN_P4"]])
