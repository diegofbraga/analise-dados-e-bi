# Roteiro de Pitch (Máximo 15 Minutos) — Equipe: Diego Feitosa & Diego Braga

**Tema:** Priorização da Fiscalização do Desmatamento na Amazônia Legal  
**Cliente:** Secretaria Estadual de Meio Ambiente  

| Bloco | Tempo | Responsável | Tópico / Foco |
| :--- | :---: | :--- | :--- |
| 1. Abertura e Problema de Negócio | 00:00 – 02:30 | Diego Feitosa | Contextualização da escala continental vs. orçamento limitado e validação do escopo (decisão clara, recorte 12m, mensurável, comparável). |
| 2. Perguntas de Negócio (P1 a P5) e KPIs | 02:30 – 05:00 | Diego Feitosa | Apresentação das 5 perguntas (Concentração, Tendência, Áreas Protegidas, Priorização e Sazonalidade) e métricas correspondentes. |
| 3. Fontes Oficiais, ETL e Mineração | 05:00 – 08:00 | Diego Braga | Bases oficiais (TerraBrasilis/DETER, IBGE, ICMBio, FUNAI), limpeza (sliver polygons < 0,03 km², janela 24m, localidade) e mineração (Buffer 10 km, Regressão OLS Beta e Normalização Min-Max). |
| 4. Modelagem Star Schema, DAX e Índice P4 | 08:00 – 11:00 | Diego Braga | Explicação do Star Schema no Power BI, fórmula do Índice de Priorização (40% Volume, 30% Tendência, 30% Proteção) e demonstração ao vivo dos visuais do dashboard. |
| 5. Resultados, Sazonalidade (P5) e Plano de Ação | 11:00 – 14:00 | Diego Feitosa & Diego Braga | Destaque para Altamira e São Félix do Xingu (Crítico), Novo Progresso (alta pressão em UCs/TIs) e o gatilho de Maio (+50% MoM) antes do pico de Agosto. |
| 6. Encerramento e Perguntas | 14:00 – 15:00 | Ambos | Síntese do valor entregue à Secretaria e abertura para perguntas da banca. |
