# Guia de Configuração no Power BI Desktop

## 1. Importação e Tipagem no Power Query (Prevenção de Erros)
- **`fAlertas_DETER_Limpo.csv`**:
  - `AREA_KM2`, `DIST_UC_TI_KM`, `LAT`, `LONG`: Alterar Tipo > Usando Localidade > **Número Decimal** > **Inglês (Estados Unidos)**.
  - `FLAG_BUFFER_10KM` e `CD_MUN`: **Número Inteiro**.
  - `VIEW_DATE`: **Data** (sem hora).
- **`dMunicipio.csv`**: `CD_MUN` como **Número Inteiro**; `LAT_CENTROIDE` e `LONG_CENTROIDE` categorizados como Latitude e Longitude.
- **`dCalendario.csv`**: `Data` como **Data**; marcar tabela como Tabela de Data; classificar `Mes_Ano` pela coluna `Ano_Mes_Ordem`.
- **`dAreasProtegidas.csv`**: `ID_AREA_PROT` e `TIPO_AREA` como **Texto**.

## 2. Modelagem Star Schema (Relacionamentos 1:N)
- `dCalendario[Data]` (1) -> (*) `fAlertas_DETER_Limpo[VIEW_DATE]`
- `dMunicipio[CD_MUN]` (1) -> (*) `fAlertas_DETER_Limpo[CD_MUN]`
- `dAreasProtegidas[ID_AREA_PROT]` (1) -> (*) `fAlertas_DETER_Limpo[ID_AREA_PROT]`

## 3. Medidas DAX e Formatação
- Todas as medidas DAX estão prontas no arquivo `05_Scripts_ETL/medidas_dax_powerbi.dax`.
- Formatar como **Porcentagem (2 casas decimais)**: `Participação no Total (%)`, `Variação Anual (%)`, `Alertas em Áreas Protegidas (%)` e `Variação Mensal (MoM %)`.

## 4. Arquitetura dos Visuais
1. **Segmentadores Independentes (Topo Direito):** `TIPO_AREA`, `CLASSNAME` e `SIGLA_UF`.
2. **Cartões de KPI (Topo Esquerdo):** Total Alertas / Área km², Variação Anual (%), Alertas em Áreas Protegidas (%), Pico Crítico Anual e Gatilho de Mobilização.
3. **Matriz Multicritério (Centro):** Municípios ordenados por `Índice de Priorização (IP)` com a coluna `Faixa de Decisão Operacional`.
4. **Gráfico Sazonal (Inferior Esquerdo):** `Variação Mensal (MoM %)` por `Mes_Ano` com linha constante em `0,35` (+35%).
5. **Gráfico de Dispersão (Inferior Direito):** Eixo X = `Total Alertas (12m)`, Eixo Y = `Tendência Mensal (Beta OLS)`, Tamanho = `Alertas em Áreas Protegidas (%)`.
