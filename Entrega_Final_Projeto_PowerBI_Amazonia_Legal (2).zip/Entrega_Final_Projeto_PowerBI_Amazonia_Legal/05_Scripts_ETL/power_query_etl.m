let
    // Substitua o caminho abaixo pelo diretório local do arquivo CSV bruto
    Fonte = Csv.Document(File.Contents("fAlertas_DETER_Bruto_TerraBrasilis.csv"), [Delimiter=",", Columns=12, Encoding=65001, QuoteStyle=QuoteStyle.None]),
    CabecalhosPromovidos = Table.PromoteHeaders(Fonte, [PromoteAllScalars=true]),
    // Tipagem forte com localidade en-US para ponto decimal em AREA_KM2, DIST_UC_TI_KM, LAT e LONG
    TipagemForte = Table.TransformColumnTypes(CabecalhosPromovidos, {
        {"GID", type text}, {"VIEW_DATE", type date}, {"CD_MUN", Int64.Type},
        {"MUNICIPIO", type text}, {"UF", type text}, {"CLASSNAME", type text},
        {"AREA_KM2", type number}, {"ID_AREA_PROT", type text},
        {"DIST_UC_TI_KM", type number}, {"FLAG_BUFFER_10KM", Int64.Type},
        {"LAT", type number}, {"LONG", type number}
    }, "en-US"),
    // Etapa 1: Janela Móvel de 24 Meses
    FiltroJanela24m = Table.SelectRows(TipagemForte, each [VIEW_DATE] >= #date(2024, 11, 1) and [VIEW_DATE] <= #date(2026, 10, 31)),
    // Etapa 2: Classes Alvo de Fiscalização
    FiltroClasses = Table.SelectRows(FiltroJanela24m, each List.Contains({"DESMATAMENTO_CR", "DESMATAMENTO_VEG", "MINERACAO"}, [CLASSNAME])),
    // Etapa 3: Remoção de Sliver Polygons (< 0,03 km²) e Duplicatas de GID
    FiltroSliver = Table.SelectRows(FiltroClasses, each [AREA_KM2] >= 0.03),
    SemDuplicatasGID = Table.Distinct(FiltroSliver, {"GID"}),
    // Etapa 4: Higienização de Textos
    PadronizaTexto = Table.TransformColumns(SemDuplicatasGID, {{"MUNICIPIO", each Text.Upper(Text.Trim(_)), type text}}),
    // Etapa 5: Recálculo auditável da Flag de Buffer <= 10 km
    CalculaBuffer10km = Table.RemoveColumns(PadronizaTexto, {"FLAG_BUFFER_10KM"}),
    AdicionaFlagBuffer = Table.AddColumn(CalculaBuffer10km, "FLAG_BUFFER_10KM", each if [DIST_UC_TI_KM] <= 10 then 1 else 0, Int64.Type)
in
    AdicionaFlagBuffer
